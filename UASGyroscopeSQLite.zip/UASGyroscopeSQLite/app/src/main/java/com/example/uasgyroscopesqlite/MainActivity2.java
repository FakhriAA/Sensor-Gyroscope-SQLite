package com.example.uasgyroscopesqlite;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import android.support.v7.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {
    private Button buttonNext;
    private Button buttonPrev;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    public void buttonNext(View view) {
        Intent intent = new Intent(MainActivity2.this, MainActivity.class);
        startActivity(intent);
    }

    public void buttonPrev(View view) {
        Intent intent = new Intent(MainActivity2.this, MainActivity2.class);
        startActivity(intent);
    }
}